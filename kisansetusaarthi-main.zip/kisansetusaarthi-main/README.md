🌾 Kisan Setu – Saarthi Farmer (Frontend)

A responsive frontend web application designed to support farmers by providing access to agricultural information, market updates, and government schemes.

This project focuses on building a clean, user-friendly interface for a farmer assistance platform.

📌 Project Overview

Kisan Setu – Saarthi Farmer is a frontend-based web application that provides:

📊 Market price display section

🌦 Weather information section

📢 Government schemes information

📚 Farming guidance and tips

🔐 Login & Registration UI

📱 Responsive design for mobile and desktop

This project demonstrates frontend development skills including layout design, responsiveness, and UI/UX implementation.

🛠 Tech Stack

HTML5

CSS3

JavaScript

Bootstrap (if used)

Responsive Web Design

(Remove Bootstrap if you didn’t use it.)

📂 Project Structure
kisansetusaarthifarmer/
│
├── index.html
├── login.html
├── register.html
├── css/
│   └── styles.css
├── js/
│   └── script.js
└── assets/
    └── images/

(Modify structure if your folder names are different.)

🚀 How to Run the Project

Since this is a frontend-only project:

1️⃣ Download or clone the repository:

git clone https://github.com/sahithi2361/kisansetusaarthifarmer.git

2️⃣ Open the project folder

3️⃣ Double-click on index.html
OR
Open index.html in your browser.

No backend setup is required.

✨ Features Implemented (UI Level)

Clean homepage layout

Navigation bar

Information sections for farmers

Login & Registration forms (UI only)

Responsive design

🎯 Purpose of the Project

This project was developed to:

Practice frontend web development

Build a real-world agriculture-based application UI

Improve HTML, CSS, and JavaScript skills

🔮 Future Improvements

Backend integration

Real-time weather API

Live market price API

Database integration

User authentication system

👩‍💻 Developer

Developed by Sahithi
